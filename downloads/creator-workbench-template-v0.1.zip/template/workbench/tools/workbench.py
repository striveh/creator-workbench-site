#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""创作者工作台 v0.1 —— 零第三方依赖的内容流水线 CLI。

用法：
    python3 workbench/tools/workbench.py --help
    python3 workbench/tools/workbench.py new "我的第一篇内容" --slug my-first-post
    python3 workbench/tools/workbench.py list
    python3 workbench/tools/workbench.py dashboard
"""

from __future__ import annotations

import argparse
import hashlib
import html
import json
import re
import sys
import unicodedata
import webbrowser
from datetime import date, datetime
from pathlib import Path

# ---------------------------------------------------------------------------
# 路径约定
# ---------------------------------------------------------------------------

WORKBENCH_DIR = Path(__file__).resolve().parent.parent
PROJECT_ROOT = WORKBENCH_DIR.parent
DEFAULT_CONTENT_DIR = PROJECT_ROOT / "content"
DASHBOARD_CONFIG = WORKBENCH_DIR / "dashboard-config.json"
DEFAULT_DASHBOARD = WORKBENCH_DIR / "dashboard.html"

STATUSES = ["选题", "写作", "待发布", "已发布"]
STATUS_ICONS = {"选题": "○", "写作": "◐", "待发布": "◑", "已发布": "●"}
STATUS_CLASS = {"选题": "idea", "写作": "writing", "待发布": "ready", "已发布": "published"}
EMPTY_HINTS = {
    "选题": ("从选题库挑一个 P0 题目", "02-选题库/选题库.md"),
    "写作": ("用公众号模板开始写", "04-模板/公众号文章模板.md"),
    "待发布": ("过一遍发布检查清单", "04-模板/发布检查清单.md"),
    "已发布": ("发布后记录数据与链接", "04-模板/周复盘模板.md"),
}
PLATFORM_NAMES = {
    "wechat": "公众号",
    "weixin": "公众号",
    "微信公众号": "公众号",
    "xiaohongshu": "小红书",
    "xhs": "小红书",
    "red": "小红书",
    "shipinhao": "视频号",
    "video": "视频号",
    "douyin": "抖音",
    "bilibili": "B站",
    "zhihu": "知乎",
    "juejin": "掘金",
    "x": "X",
    "twitter": "X",
}

STATUS_ALIASES = {
    "选题": "选题",
    "idea": "选题",
    "topic": "选题",
    "构思": "选题",
    "待选题": "选题",
    "写作": "写作",
    "draft": "写作",
    "writing": "写作",
    "草稿": "写作",
    "初稿": "写作",
    "撰写中": "写作",
    "in_progress": "写作",
    "in-progress": "写作",
    "待发布": "待发布",
    "ready": "待发布",
    "review": "待发布",
    "reviewing": "待发布",
    "待审": "待发布",
    "审核中": "待发布",
    "已完成": "待发布",
    "pending": "待发布",
    "已发布": "已发布",
    "published": "已发布",
    "发布": "已发布",
    "已发": "已发布",
    "done": "已发布",
    "完成": "已发布",
}

DEFAULT_CONFIG = {
    "start_date": "",
    "north_star": "90 天跑通首单",
    "goals": [
        {
            "title": "30 天发布 10 篇内容",
            "target": 10,
            "metric": "published",
            "unit": "篇",
            "note": "至少 4 篇长文，其余拆成图文/视频；至少 3 篇收到有效评论或私信；记录读完率基线",
        },
        {
            "title": "60 天产出 1 套可复用模板 + 1 个小工具",
            "target": 2,
            "metric": "manual",
            "done": 0,
            "unit": "项",
            "note": "把高复用结构做成模板，把重复动作做成工具",
        },
        {
            "title": "90 天跑通首单",
            "target": 1,
            "metric": "manual",
            "done": 0,
            "unit": "单",
            "note": "第一笔真实定价付费（哪怕 9.9 元），完成交付并取得 1 个案例授权",
        },
    ],
    "week": {
        "label": "第 1 周 · 示例周（请改成你的日期）",
        "focus": "先完成第一篇内容并发布。",
        "todos": [
            {"text": "示例：填写 01-定位/定位画布.md 与个人资产盘点.md", "done": False},
            {"text": "示例：从选题库挑 3 个题目，用选题卡打分", "done": False},
            {"text": "示例：用 workbench.py new 新建第一篇内容", "done": False},
            {"text": "示例：完成首篇初稿并配图", "done": False},
            {"text": "示例：运行 dashboard 并更新本周待办", "done": False},
        ],
    },
}


# ---------------------------------------------------------------------------
# 通用工具
# ---------------------------------------------------------------------------


def e(value: object) -> str:
    """HTML 转义。"""
    return html.escape(str(value), quote=True)


def today_str() -> str:
    return date.today().isoformat()


def normalize_status(raw: object) -> str:
    """把各种写法统一成四个标准状态之一。"""
    text = str(raw or "").strip()
    if not text:
        return "选题"
    key = text.lower().replace(" ", "").replace("_", "-")
    if key in STATUS_ALIASES:
        return STATUS_ALIASES[key]
    # 容错：包含关键词
    if "已发" in text or "发布完成" in text:
        return "已发布"
    if "发布" in text or "review" in key:
        return "待发布"
    if "写" in text or "draft" in key:
        return "写作"
    if "选" in text or "idea" in key:
        return "选题"
    return "选题"


def slugify(text: str, max_len: int = 48) -> str:
    """生成 ASCII slug；中文标题会退化为 article-<hash>，可用 --slug 覆盖。"""
    normalized = unicodedata.normalize("NFKD", text)
    ascii_text = normalized.encode("ascii", "ignore").decode("ascii")
    slug = re.sub(r"[^a-zA-Z0-9]+", "-", ascii_text).strip("-").lower()
    if len(slug) < 3:
        digest = hashlib.sha1(text.encode("utf-8")).hexdigest()[:6]
        slug = "article-" + digest
    slug = slug[:max_len].strip("-")
    return slug or "article"


def parse_date_value(value: object) -> str:
    """从各种日期写法里提取 YYYY-MM-DD，失败返回空串。"""
    if value is None:
        return ""
    text = str(value).strip()
    match = re.match(r"(\d{4})-(\d{2})-(\d{2})", text)
    if match:
        return match.group(0)
    return ""


def folder_date(name: str) -> str:
    match = re.match(r"^(\d{4}-\d{2}-\d{2})-", name)
    return match.group(1) if match else ""


def first_value(meta: dict, keys: list[str], default: str = "") -> str:
    for key in keys:
        value = meta.get(key)
        if value not in (None, "", [], {}):
            if isinstance(value, (list, tuple)):
                return "、".join(str(item) for item in value)
            return str(value).strip()
    return default


def read_text(path: Path, limit: int = 4000) -> str:
    try:
        return path.read_text(encoding="utf-8")[:limit]
    except (OSError, UnicodeDecodeError):
        return ""


def article_title(path: Path) -> str:
    text = read_text(path, 3000)
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.lower().startswith("title:"):
            value = stripped.split(":", 1)[1].strip().strip("\"'")
            if value:
                return value
        if stripped.startswith("# "):
            return stripped[2:].strip()
    return ""


def article_summary(path: Path) -> str:
    text = read_text(path, 6000)
    in_frontmatter = False
    for index, line in enumerate(text.splitlines()):
        stripped = line.strip()
        if index == 0 and stripped == "---":
            in_frontmatter = True
            continue
        if in_frontmatter:
            if stripped == "---":
                in_frontmatter = False
            continue
        if not stripped or stripped.startswith("#") or stripped.startswith(">") or stripped.startswith("-"):
            continue
        if stripped.startswith("<!--") or re.match(r"^[a-zA-Z_][a-zA-Z0-9_]*\s*:", stripped):
            continue
        stripped = re.sub(r"[*_`]", "", stripped)
        if len(stripped) >= 20:
            return stripped[:72] + ("…" if len(stripped) > 72 else "")
    return ""


def load_json(path: Path) -> dict:
    try:
        with path.open("r", encoding="utf-8") as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except (OSError, json.JSONDecodeError):
        return {}


def write_json(path: Path, data: dict) -> None:
    with path.open("w", encoding="utf-8") as handle:
        json.dump(data, handle, ensure_ascii=False, indent=2)
        handle.write("\n")


# ---------------------------------------------------------------------------
# 内容数据模型
# ---------------------------------------------------------------------------


class Item:
    """一篇内容的视图模型（不依赖具体 meta.json 字段名）。"""

    def __init__(self, folder: Path, meta: dict):
        self.folder = folder
        self.meta = meta
        self.name = folder.name
        self.article = folder / "article.md"

        title = first_value(meta, ["title", "标题", "name", "名称"])
        if not title:
            title = article_title(self.article)
        self.title = title or self.name

        self.status = normalize_status(first_value(meta, ["status", "状态", "stage", "阶段"], "选题"))

        raw_date = first_value(meta, ["date", "created", "created_at", "创建日期", "日期", "发布日期"])
        self.date = parse_date_value(raw_date) or folder_date(self.name) or "待填写"

        column = first_value(
            meta, ["column", "栏目", "pillar", "category", "分类", "content_pillar", "内容支柱"]
        )
        if not column:
            tags = meta.get("tags") or meta.get("标签") or []
            if isinstance(tags, str):
                tags = [tags]
            if isinstance(tags, list) and tags:
                column = str(tags[0])
        self.column = column or "未分类"

        platforms = meta.get("platforms") or meta.get("平台") or meta.get("channels") or []
        if isinstance(platforms, str):
            platforms = re.split(r"[,，/、\s]+", platforms)
        self.platforms = [str(item).strip() for item in platforms if str(item).strip()]

        summary = first_value(meta, ["summary", "摘要", "description", "简介", "desc"])
        self.summary = summary or article_summary(self.article)

        self.updated = first_value(meta, ["updated", "updated_at", "更新日期", "修改时间"])

    @property
    def rel_path(self) -> str:
        try:
            return str(self.folder.relative_to(PROJECT_ROOT))
        except ValueError:
            return str(self.folder)

    @property
    def link(self) -> str:
        # dashboard.html 位于 workbench/，content/ 与 workbench/ 同级
        return f"../content/{self.name}/article.md"


def load_items(content_dir: Path) -> list[Item]:
    """扫描 content/*/，有 meta.json 或 article.md 的目录视为内容。"""
    if not content_dir.exists():
        return []
    items: list[Item] = []
    for child in sorted(content_dir.iterdir()):
        if not child.is_dir() or child.name.startswith("."):
            continue
        if not (child / "meta.json").exists() and not (child / "article.md").exists():
            continue
        items.append(Item(child, load_json(child / "meta.json")))
    return items


def sort_items(items: list[Item]) -> list[Item]:
    def key(item: Item):
        status_index = STATUSES.index(item.status) if item.status in STATUSES else 99
        return (status_index, item.date == "待填写", item.date, item.title)

    return sorted(items, key=key)


def find_item(content_dir: Path, target: str) -> Item | None:
    direct = Path(target)
    if direct.is_dir():
        return Item(direct, load_json(direct / "meta.json"))
    for item in load_items(content_dir):
        if item.name == target or item.meta.get("slug") == target or item.title == target:
            return item
    for item in load_items(content_dir):
        if target in item.name or target in item.title:
            return item
    return None


# ---------------------------------------------------------------------------
# 命令：new
# ---------------------------------------------------------------------------


ARTICLE_TEMPLATE = """# {title}

- 状态：{status}
- 栏目：{column}
- 目标读者：待填写
- 核心观点：待填写
- 发布平台：公众号 / 小红书 / 视频号

## 开头（150–250 字）

待填写：一个具体场景、冲突或反常识判断。

## 正文

### 一、待填写

待填写：场景 → 问题 → 判断 → 方法 → 边界。

### 二、待填写

待填写。

## 结尾

- 总结：待填写
- 行动：待填写
- 互动：待填写

---

<!-- 写作模板：workbench/04-模板/公众号文章模板.md -->
"""


def cmd_new(args: argparse.Namespace) -> int:
    title = (args.title or "").strip()
    if not title:
        print("错误：标题不能为空。", file=sys.stderr)
        return 2

    content_dir = Path(args.content_dir).expanduser().resolve() if args.content_dir else DEFAULT_CONTENT_DIR
    try:
        day = date.fromisoformat(args.date) if args.date else date.today()
    except ValueError:
        print("错误：--date 必须是 YYYY-MM-DD 格式。", file=sys.stderr)
        return 2

    slug = slugify(args.slug if args.slug else title)
    folder_name = f"{day.isoformat()}-{slug}"
    folder = content_dir / folder_name
    suffix = 2
    while folder.exists():
        folder = content_dir / f"{folder_name}-{suffix}"
        suffix += 1

    try:
        (folder / "imgs").mkdir(parents=True, exist_ok=False)
        (folder / "prompts").mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        print(f"错误：创建目录失败：{exc}", file=sys.stderr)
        return 1

    status = normalize_status(args.status)
    article = ARTICLE_TEMPLATE.format(title=title, status=status, column=args.column or "未分类")
    (folder / "article.md").write_text(article, encoding="utf-8")

    meta = {
        "title": title,
        "slug": folder.name[len(day.isoformat()) + 1 :],
        "status": status,
        "column": args.column or "未分类",
        "created": day.isoformat(),
        "updated": datetime.now().isoformat(timespec="seconds"),
        "target_reader": "待填写",
        "platforms": ["公众号", "小红书", "视频号"],
        "tags": [],
        "summary": "",
        "cover": "",
        "files": {"article": "article.md", "imgs": "imgs/", "prompts": "prompts/"},
    }
    write_json(folder / "meta.json", meta)

    print("已创建内容目录：")
    print(f"  {folder}")
    print()
    print("包含：article.md / meta.json / imgs/ / prompts/")
    print("下一步：编辑 article.md，然后运行 workbench.py list 查看状态。")
    return 0


# ---------------------------------------------------------------------------
# 命令：list
# ---------------------------------------------------------------------------


def cmd_list(args: argparse.Namespace) -> int:
    content_dir = Path(args.content_dir).expanduser().resolve() if args.content_dir else DEFAULT_CONTENT_DIR
    items = load_items(content_dir)
    if args.status:
        wanted = normalize_status(args.status)
        items = [item for item in items if item.status == wanted]
    items = sort_items(items)

    if args.json:
        payload = [
            {
                "title": item.title,
                "status": item.status,
                "column": item.column,
                "date": item.date,
                "path": item.rel_path,
                "platforms": item.platforms,
                "summary": item.summary,
            }
            for item in items
        ]
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        return 0

    if not items:
        print("内容清单为空。")
        print("运行：python3 workbench/tools/workbench.py new \"你的标题\" --slug your-slug")
        return 0

    print(f"创作者工作台 · 内容清单（共 {len(items)} 篇）")
    print("=" * 60)
    for status in STATUSES:
        group = [item for item in items if item.status == status]
        if args.status and not group:
            continue
        print(f"\n{STATUS_ICONS[status]} {status}（{len(group)}）")
        if not group:
            print("  ——")
            continue
        for item in group:
            print(f"  · {item.date}  {item.title}  [{item.column}]")
            print(f"    {item.rel_path}")
    print()
    print("提示：运行 dashboard 命令生成可视化看板。")
    return 0


# ---------------------------------------------------------------------------
# 命令：status
# ---------------------------------------------------------------------------


def cmd_status(args: argparse.Namespace) -> int:
    content_dir = Path(args.content_dir).expanduser().resolve() if args.content_dir else DEFAULT_CONTENT_DIR
    item = find_item(content_dir, args.target)
    if item is None:
        print(f"错误：找不到内容「{args.target}」。", file=sys.stderr)
        return 1
    new_status = normalize_status(args.new_status)
    item.meta["status"] = new_status
    item.meta["updated"] = datetime.now().isoformat(timespec="seconds")
    write_json(item.folder / "meta.json", item.meta)
    print(f"已更新《{item.title}》状态为：{new_status}")
    print(f"目录：{item.folder}")
    return 0


# ---------------------------------------------------------------------------
# 命令：dashboard
# ---------------------------------------------------------------------------


def load_config() -> dict:
    config = json.loads(json.dumps(DEFAULT_CONFIG, ensure_ascii=False))
    custom = load_json(DASHBOARD_CONFIG)
    if custom:
        for key, value in custom.items():
            if key in ("goals", "week") and isinstance(value, (list, dict)):
                config[key] = value
            else:
                config[key] = value
    return config


def goal_progress(goal: dict, items: list[Item]) -> tuple[float, float, str]:
    """返回 (完成值, 目标值, 展示文本)。"""
    metric = goal.get("metric", "manual")
    target = float(goal.get("target", 1) or 1)
    if metric == "published":
        done = float(sum(1 for item in items if item.status == "已发布"))
    elif metric == "total":
        done = float(len(items))
    elif metric == "writing":
        done = float(sum(1 for item in items if item.status == "写作"))
    else:
        done = float(goal.get("done", 0) or 0)
    percent = max(0.0, min(100.0, done / target * 100)) if target else 0.0
    done_text = str(int(done)) if done == int(done) else f"{done:.1f}"
    target_text = str(int(target)) if target == int(target) else f"{target:.1f}"
    unit = str(goal.get("unit", ""))
    return percent, done, f"{done_text} / {target_text}{unit}"


def render_kpi(label: str, value: int | str, hint: str, accent: str = "") -> str:
    cls = f" kpi-{accent}" if accent else ""
    return (
        f'<div class="kpi{cls}"><div class="kpi-label">{e(label)}</div>'
        f'<div class="kpi-value">{e(value)}</div><div class="kpi-hint">{e(hint)}</div></div>'
    )


def render_goal(goal: dict, index: int, items: list[Item]) -> str:
    percent, done, text = goal_progress(goal, items)
    return (
        f'<article class="goal">'
        f'<div class="goal-top"><span class="goal-index">{index:02d}</span>'
        f'<span class="goal-percent">{percent:.0f}%</span></div>'
        f'<h3>{e(goal.get("title", "未命名目标"))}</h3>'
        f'<div class="goal-bar"><i style="width:{percent:.1f}%"></i></div>'
        f'<div class="goal-bottom"><strong>{e(text)}</strong>'
        f'<span>{e(goal.get("note", ""))}</span></div>'
        f"</article>"
    )


def render_card(item: Item) -> str:
    platforms = "".join(
        f'<span class="chip">{e(PLATFORM_NAMES.get(p.lower(), p))}</span>' for p in item.platforms[:3]
    )
    summary = f'<p class="item-summary">{e(item.summary)}</p>' if item.summary else ""
    date_text = item.date if item.date != "待填写" else "日期待填写"
    if item.date != "待填写" and len(item.date) == 10:
        date_text = item.date[5:].replace("-", "/")
    title = e(item.title)
    if item.article.exists():
        title_html = f'<a class="item-title" href="{e(item.link)}">{title}</a>'
    else:
        title_html = f'<span class="item-title">{title}</span>'
    return (
        f'<article class="item">'
        f'<div class="item-top"><span class="pillar">{e(item.column)}</span>'
        f"<time>{e(date_text)}</time></div>"
        f"{title_html}{summary}"
        f'<div class="item-foot">{platforms}</div>'
        f"</article>"
    )


def next_action(items: list[Item]) -> tuple[str, str]:
    if not items:
        return "创建第一篇内容", '运行 workbench.py new "你的标题" --slug your-slug 开始。'
    for status in ["待发布", "写作", "选题"]:
        group = [item for item in items if item.status == status]
        if group:
            item = sort_items(group)[0]
            if status == "待发布":
                return f"发布《{item.title}》", "按《发布检查清单》过一遍，今天发出去。"
            if status == "写作":
                return f"写完《{item.title}》", "先完成初稿，不要边写边改。"
            return f"开始写《{item.title}》", "用选题卡确认价值，然后列一个三节提纲。"
    return "开始下一篇", "当前内容都已发布，从选题库挑下一个 P0 题目。"


def render_dashboard(items: list[Item], config: dict) -> str:
    items = sort_items(items)
    counts = {status: sum(1 for item in items if item.status == status) for status in STATUSES}

    raw_start = parse_date_value(config.get("start_date"))
    start_date = raw_start or "待填写"
    if raw_start:
        try:
            day_index = (date.today() - date.fromisoformat(raw_start)).days + 1
        except ValueError:
            day_index = None
    else:
        day_index = None
    if day_index is not None and 1 <= day_index <= 90:
        phase_text = f"第 {day_index} / 90 天"
    else:
        phase_text = "90 天计划"

    weekday_names = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"]
    today = date.today()
    date_text = f"{today.month} 月 {today.day} 日 · {weekday_names[today.weekday()]}"

    kpis = "".join(
        [
            render_kpi("内容总数", len(items), "全部内容", "total"),
            render_kpi("已发布", counts["已发布"], "目标 10 篇", "published"),
            render_kpi("写作中", counts["写作"], "正在推进", "writing"),
            render_kpi("待发布", counts["待发布"], "等待最后检查", "ready"),
            render_kpi("选题库存", counts["选题"], "可随时开工", "idea"),
        ]
    )

    goals = "".join(render_goal(goal, index + 1, items) for index, goal in enumerate(config.get("goals", [])))

    columns = []
    for status in STATUSES:
        group = [item for item in items if item.status == status]
        cards = "".join(render_card(item) for item in group)
        if not cards:
            hint_text, hint_file = EMPTY_HINTS[status]
            cards = (
                '<div class="empty"><div class="empty-mark">＋</div>'
                f"<p>{hint_text}</p><small>{hint_file}</small></div>"
            )
        columns.append(
            f'<section class="column col-{STATUS_CLASS[status]}">'
            f'<div class="col-head"><span class="dot"></span><h3>{status}</h3>'
            f'<span class="count">{len(group)}</span></div>'
            f'<div class="cards">{cards}</div></section>'
        )

    week = config.get("week", {})
    todos = week.get("todos", [])
    todo_done = sum(1 for todo in todos if todo.get("done"))
    todo_html = "".join(
        f'<li class="{"is-done" if todo.get("done") else ""}">'
        f'<span class="check">{"✓" if todo.get("done") else ""}</span>'
        f'<span class="todo-text">{e(todo.get("text", ""))}</span></li>'
        for todo in todos
    )
    if not todos:
        todo_html = '<li class="is-empty">还没有待办，去 dashboard-config.json 添加。</li>'

    action_title, action_note = next_action(items)

    html_doc = "".join(
        [
            HTML_HEAD,
            '<header class="hero">',
            '<div class="brand"><span class="brand-mark"></span>CREATOR WORKBENCH <em>v0.1</em></div>',
            '<div class="hero-row"><div>',
            "<h1>创作者工作台</h1>",
            '<p class="sub">把多年的专业经验，加工成内容、工具与产品</p>',
            "</div>",
            f'<div class="hero-meta"><div class="date">{e(date_text)}</div>',
            f'<div class="phase">{e(phase_text)} <span>· {e(config.get("north_star", "90 天跑通首单"))}</span></div></div>',
            "</div></header>",
            f'<section class="kpis">{kpis}</section>',
            '<section class="block"><div class="section-head"><h2>90 天目标</h2>',
            f'<span>起点 {e(start_date)} · 以产出为准</span></div>',
            f'<div class="goals">{goals}</div></section>',
            '<section class="block"><div class="section-head"><h2>内容流水线</h2>',
            f'<span>共 {len(items)} 篇 · 数据来自 content/*/meta.json</span></div>',
            f'<div class="pipeline">{"".join(columns)}</div></section>',
            '<section class="bottom">',
            f'<div class="panel todo"><div class="panel-head"><h2>本周待办</h2><span>{todo_done} / {len(todos)} 完成</span></div>',
            f'<p class="panel-label">{e(week.get("label", "本周"))}</p>',
            f'<ul class="todo-list">{todo_html}</ul>',
            f'<p class="focus">本周只抓一件事：{e(week.get("focus", ""))}</p></div>',
            '<div class="panel tip"><div class="panel-head"><h2>今日建议</h2><span>由流水线自动推荐</span></div>',
            f'<div class="tip-title">{e(action_title)}</div>',
            f'<p class="tip-note">{e(action_note)}</p>',
            '<div class="tip-rule"></div>',
            '<p class="tip-small">发布不是终点，是获得反馈的起点。每篇发布后 24 小时内记录数据，周日复盘。</p>',
            "</div></section>",
            f'<footer>由 workbench/tools/workbench.py 自动生成 · 数据源 content/*/meta.json</footer>',
            "</div></body></html>",
        ]
    )
    return html_doc


HTML_HEAD = """<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>创作者工作台 · v0.1</title>
<style>
:root {
  --bg: #071321;
  --bg-2: #0b1b31;
  --card: #10233d;
  --card-2: #132b4b;
  --line: rgba(148, 178, 214, 0.16);
  --text: #eaf1fa;
  --muted: #9fb2c9;
  --accent: #f5a35c;
  --accent-2: #ff7a45;
  --green: #67d4a2;
  --blue: #6db5ff;
  --violet: #b69cff;
}
* { box-sizing: border-box; }
html, body { margin: 0; padding: 0; }
body {
  background:
    radial-gradient(1100px 560px at 12% -8%, rgba(35, 84, 140, 0.55) 0%, transparent 58%),
    radial-gradient(800px 420px at 92% 4%, rgba(245, 163, 92, 0.10) 0%, transparent 55%),
    var(--bg);
  color: var(--text);
  font-family: -apple-system, BlinkMacSystemFont, "PingFang SC", "Hiragino Sans GB",
    "Microsoft YaHei", "Noto Sans CJK SC", sans-serif;
  -webkit-font-smoothing: antialiased;
  min-height: 100vh;
}
.page { max-width: 1440px; margin: 0 auto; padding: 36px 40px 48px; }
.hero { padding: 8px 0 26px; }
.brand {
  display: flex; align-items: center; gap: 10px;
  font-size: 11px; letter-spacing: 0.22em; color: var(--muted);
  font-weight: 600; margin-bottom: 22px;
}
.brand-mark { width: 8px; height: 8px; border-radius: 2px; background: var(--accent); box-shadow: 0 0 18px rgba(245, 163, 92, .8); }
.brand em { font-style: normal; color: var(--accent); letter-spacing: 0.08em; }
.hero-row { display: flex; justify-content: space-between; align-items: flex-end; gap: 24px; flex-wrap: wrap; }
h1 { font-size: 42px; line-height: 1.1; margin: 0 0 10px; letter-spacing: -0.02em; font-weight: 700; }
.sub { margin: 0; color: var(--muted); font-size: 15px; letter-spacing: 0.02em; }
.hero-meta { text-align: right; }
.date { font-size: 14px; color: var(--text); font-weight: 600; }
.phase { margin-top: 6px; font-size: 12px; color: var(--accent); letter-spacing: 0.04em; }
.phase span { color: var(--muted); }

.kpis { display: grid; grid-template-columns: repeat(5, minmax(0, 1fr)); gap: 12px; margin-bottom: 8px; }
.kpi {
  background: linear-gradient(180deg, rgba(255,255,255,.035), rgba(255,255,255,0) 60%), var(--card);
  border: 1px solid var(--line); border-radius: 15px; padding: 16px 18px;
  position: relative; overflow: hidden;
}
.kpi::after { content: ""; position: absolute; left: 0; top: 0; width: 3px; height: 100%; background: var(--line); }
.kpi-total::after { background: var(--blue); opacity: .55; }
.kpi-published::after { background: var(--green); }
.kpi-writing::after { background: var(--accent); }
.kpi-ready::after { background: var(--violet); }
.kpi-idea::after { background: var(--muted); }
.kpi-label { font-size: 12px; color: var(--muted); letter-spacing: .08em; }
.kpi-value { font-size: 30px; font-weight: 700; line-height: 1.25; margin-top: 4px; font-variant-numeric: tabular-nums; }
.kpi-hint { font-size: 11px; color: var(--muted); opacity: .85; margin-top: 2px; }

.block { margin-top: 38px; }
.section-head { display: flex; align-items: baseline; justify-content: space-between; gap: 16px; margin-bottom: 14px; }
.section-head h2 { font-size: 18px; margin: 0; letter-spacing: .02em; display: flex; align-items: center; gap: 9px; }
.section-head h2::before { content: ""; width: 5px; height: 16px; background: var(--accent); border-radius: 3px; display: inline-block; }
.section-head > span { font-size: 12px; color: var(--muted); }

.goals { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 14px; }
.goal {
  background: linear-gradient(160deg, rgba(255,255,255,.045), rgba(255,255,255,0) 55%), var(--card);
  border: 1px solid var(--line); border-radius: 16px; padding: 18px 20px 16px;
}
.goal-top { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; }
.goal-index { font-size: 11px; letter-spacing: .16em; color: var(--accent); font-weight: 700; }
.goal-percent { font-size: 12px; color: var(--muted); font-variant-numeric: tabular-nums; }
.goal h3 { margin: 0 0 14px; font-size: 16px; line-height: 1.45; font-weight: 600; }
.goal-bar { height: 7px; border-radius: 99px; background: rgba(255,255,255,.08); overflow: hidden; margin-bottom: 12px; }
.goal-bar i { display: block; height: 100%; border-radius: 99px; background: linear-gradient(90deg, var(--accent-2), var(--accent)); box-shadow: 0 0 16px rgba(245,163,92,.35); }
.goal-bottom { display: flex; justify-content: space-between; gap: 12px; align-items: baseline; }
.goal-bottom strong { font-size: 13px; color: var(--text); font-variant-numeric: tabular-nums; white-space: nowrap; }
.goal-bottom span { font-size: 11px; color: var(--muted); text-align: right; line-height: 1.5; }

.pipeline { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 14px; align-items: start; }
.column { background: rgba(16, 35, 61, .58); border: 1px solid var(--line); border-radius: 16px; padding: 14px; min-height: 230px; }
.col-head { display: flex; align-items: center; gap: 8px; padding: 2px 4px 12px; border-bottom: 1px solid var(--line); margin-bottom: 12px; }
.col-head h3 { margin: 0; font-size: 14px; font-weight: 600; letter-spacing: .04em; }
.col-head .count { margin-left: auto; font-size: 11px; color: var(--muted); background: rgba(255,255,255,.06); border-radius: 99px; padding: 2px 8px; }
.dot { width: 7px; height: 7px; border-radius: 50%; }
.col-idea .dot { background: var(--muted); }
.col-writing .dot { background: var(--accent); }
.col-ready .dot { background: var(--violet); }
.col-published .dot { background: var(--green); }
.cards { display: flex; flex-direction: column; gap: 10px; }
.item { background: var(--card-2); border: 1px solid transparent; border-radius: 12px; padding: 13px 14px; transition: border-color .15s ease, transform .15s ease; }
.item:hover { border-color: rgba(245, 163, 92, .5); transform: translateY(-1px); }
.item-top { display: flex; justify-content: space-between; gap: 10px; align-items: center; margin-bottom: 7px; }
.pillar { font-size: 10px; color: var(--accent); border: 1px solid rgba(245,163,92,.3); background: rgba(245,163,92,.08); padding: 2px 7px; border-radius: 99px; white-space: nowrap; }
.item time { font-size: 10px; color: var(--muted); font-variant-numeric: tabular-nums; }
.item-title { display: block; color: var(--text); text-decoration: none; font-size: 14px; line-height: 1.5; font-weight: 600; }
a.item-title:hover { color: var(--accent); }
.item-summary { margin: 7px 0 0; font-size: 11px; color: var(--muted); line-height: 1.6; }
.item-foot { display: flex; flex-wrap: wrap; gap: 5px; margin-top: 9px; }
.chip { font-size: 10px; color: var(--muted); background: rgba(255,255,255,.055); padding: 2px 7px; border-radius: 4px; }
.empty { border: 1px dashed rgba(148,178,214,.25); border-radius: 12px; padding: 30px 12px; text-align: center; color: var(--muted); }
.empty-mark { font-size: 22px; color: rgba(245,163,92,.6); line-height: 1; margin-bottom: 8px; }
.empty p { margin: 0 0 5px; font-size: 12px; }
.empty small { font-size: 10px; opacity: .7; font-family: "SF Mono", Menlo, monospace; }

.bottom { display: grid; grid-template-columns: 1.25fr .75fr; gap: 14px; margin-top: 38px; }
.panel { background: var(--card); border: 1px solid var(--line); border-radius: 16px; padding: 20px 22px; }
.panel-head { display: flex; justify-content: space-between; align-items: baseline; gap: 12px; margin-bottom: 4px; }
.panel-head h2 { font-size: 16px; margin: 0; }
.panel-head > span { font-size: 11px; color: var(--muted); }
.panel-label { margin: 0 0 12px; font-size: 11px; color: var(--accent); letter-spacing: .05em; }
.todo-list { list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 9px; }
.todo-list li { display: flex; align-items: flex-start; gap: 10px; font-size: 13px; line-height: 1.5; color: var(--text); }
.check { width: 16px; height: 16px; flex: 0 0 16px; margin-top: 1px; border: 1px solid rgba(148,178,214,.45); border-radius: 4px; font-size: 11px; line-height: 14px; text-align: center; color: var(--bg); }
.todo-list li.is-done { color: var(--muted); }
.todo-list li.is-done .check { background: var(--green); border-color: var(--green); color: #062015; }
.todo-list li.is-done .todo-text { text-decoration: line-through; text-decoration-color: rgba(159,178,201,.5); }
.todo-list li.is-empty { color: var(--muted); font-size: 12px; }
.focus { margin: 16px 0 0; padding-top: 12px; border-top: 1px solid var(--line); font-size: 11px; color: var(--muted); }
.tip { display: flex; flex-direction: column; }
.tip-title { font-size: 20px; font-weight: 700; line-height: 1.45; margin: 10px 0 8px; color: var(--accent); }
.tip-note { margin: 0; font-size: 12px; color: var(--muted); line-height: 1.7; }
.tip-rule { height: 1px; background: var(--line); margin: 16px 0 12px; }
.tip-small { margin: 0; font-size: 11px; color: var(--muted); line-height: 1.7; }
footer { margin-top: 30px; padding-top: 16px; border-top: 1px solid var(--line); text-align: center; font-size: 10px; color: rgba(159,178,201,.65); letter-spacing: .04em; }

@media (max-width: 1080px) {
  .page { padding: 28px 22px 36px; }
  .kpis { grid-template-columns: repeat(3, minmax(0, 1fr)); }
  .pipeline { grid-template-columns: repeat(2, minmax(0, 1fr)); }
  .goals { grid-template-columns: 1fr; }
  .bottom { grid-template-columns: 1fr; }
}
@media (max-width: 640px) {
  h1 { font-size: 30px; }
  .kpis { grid-template-columns: repeat(2, minmax(0, 1fr)); }
  .pipeline { grid-template-columns: 1fr; }
  .hero-meta { text-align: left; }
}
@media print {
  body { background: #fff; color: #111; }
  .page { max-width: none; }
  .column, .goal, .kpi, .panel, .item { background: #fff; border-color: #ddd; }
  .sub, .kpi-label, .kpi-hint, .goal-bottom span, .item-summary, .item time { color: #666; }
}
</style>
</head>
<body>
<div class="page">
"""


def cmd_dashboard(args: argparse.Namespace) -> int:
    content_dir = Path(args.content_dir).expanduser().resolve() if args.content_dir else DEFAULT_CONTENT_DIR
    output = Path(args.output).expanduser().resolve() if args.output else DEFAULT_DASHBOARD

    items = load_items(content_dir)
    config = load_config()
    doc = render_dashboard(items, config)
    try:
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(doc, encoding="utf-8")
    except OSError as exc:
        print(f"错误：写入看板失败：{exc}", file=sys.stderr)
        return 1

    print(f"看板已生成：{output}")
    print(f"内容数量：{len(items)} 篇（数据源：{content_dir}）")
    if args.open:
        try:
            webbrowser.open(output.as_uri())
        except Exception:  # noqa: BLE001 - 打不开浏览器不影响生成结果
            pass
    return 0


# ---------------------------------------------------------------------------
# CLI 入口
# ---------------------------------------------------------------------------


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="workbench.py",
        description="创作者工作台 v0.1：管理内容流水线，并从 content/*/meta.json 生成看板。",
        epilog="示例：python3 workbench/tools/workbench.py new \"我的第一篇内容\" --slug my-first-post",
    )
    subparsers = parser.add_subparsers(dest="command", metavar="命令")

    new_parser = subparsers.add_parser("new", help="新建一篇内容（创建目录、article.md、meta.json、imgs/、prompts/）")
    new_parser.add_argument("title", help="内容标题，例如：我的第一篇内容")
    new_parser.add_argument("--slug", default="", help="目录英文 slug，例如 my-first-post（不填则自动生成）")
    new_parser.add_argument("--date", default="", help="创建日期 YYYY-MM-DD，默认今天")
    new_parser.add_argument("--column", default="未分类", help="栏目，例如：AI 落地实战 / 技术人转型 / 工具与工作台 / 行业判断")
    new_parser.add_argument("--status", default="选题", choices=STATUSES, help="初始状态，默认：选题")
    new_parser.add_argument("--content-dir", default="", help="内容目录（默认：项目根目录/content）")
    new_parser.set_defaults(func=cmd_new)

    list_parser = subparsers.add_parser("list", help="按状态列出所有内容")
    list_parser.add_argument("--status", default="", help="只看某个状态：选题 / 写作 / 待发布 / 已发布")
    list_parser.add_argument("--json", action="store_true", help="以 JSON 输出，方便脚本处理")
    list_parser.add_argument("--content-dir", default="", help="内容目录（默认：项目根目录/content）")
    list_parser.set_defaults(func=cmd_list)

    status_parser = subparsers.add_parser("status", help="修改一篇内容的状态")
    status_parser.add_argument("target", help="内容目录名、slug 或标题关键词")
    status_parser.add_argument("new_status", choices=STATUSES, help="新状态")
    status_parser.add_argument("--content-dir", default="", help="内容目录（默认：项目根目录/content）")
    status_parser.set_defaults(func=cmd_status)

    dashboard_parser = subparsers.add_parser("dashboard", help="从 content/*/meta.json 生成 workbench/dashboard.html")
    dashboard_parser.add_argument("--output", default="", help="输出路径（默认：workbench/dashboard.html）")
    dashboard_parser.add_argument("--content-dir", default="", help="内容目录（默认：项目根目录/content）")
    dashboard_parser.add_argument("--open", action="store_true", help="生成后用默认浏览器打开")
    dashboard_parser.set_defaults(func=cmd_dashboard)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if not getattr(args, "command", None):
        parser.print_help()
        return 0
    return int(args.func(args))


if __name__ == "__main__":
    sys.exit(main())
