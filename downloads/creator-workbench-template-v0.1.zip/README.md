# 创作者工作台模板 v0.1

> 这是一个可以直接复制的个人创作者工作台：用一个文件夹管理定位、选题、素材、写作、发布和复盘，自带零依赖 Python CLI 与本地看板。

## 目录结构

```
template/
├── README.md              # 本文件
├── AGENTS.md              # 给 DSH Agent 的通用运行规则（可按需修改）
├── content/               # 所有内容项目（CLI 会自动创建子目录）
└── workbench/             # 工作台主体
    ├── README.md          # 工作台使用说明
    ├── 00-工作台手册.md    # 定位、内容支柱、90 天目标、核心指标
    ├── dashboard.html     # 本地看板（可重新生成）
    ├── dashboard-config.json
    ├── 01-定位/           # 空白模板，先填这里
    ├── 02-选题库/         # 39 个示例选题 + 排期模板
    ├── 03-素材库/         # 空白素材库与示例金句
    ├── 04-模板/           # 文章、选题卡、发布检查、周复盘模板
    ├── 05-产品/           # 产品路线图模板
    ├── 05-发布记录/       # 发布台账模板
    ├── 06-日志/           # 日志模板
    └── tools/             # workbench.py 与命令说明
```

## 三步开始

1. 把 `template/` 整个目录复制到你自己的电脑上（可以改名，例如 `my-workbench/`）。
2. 进入目录，运行 `python3 workbench/tools/workbench.py --help`，确认 Python 环境可用。
3. 按 `workbench/01-定位/定位画布.md` 填写你的真实信息，然后用 `workbench.py new` 新建第一篇内容。

详细步骤见 `workbench/README.md`（本模板内）；如果你拿到的是完整产品包，也可以先读包外的 `QUICKSTART.md`。

## 你需要先替换的地方

- `workbench/01-定位/`：全部是空白模板，必须填成你自己的。
- `workbench/02-选题库/选题库.md`：39 个题目是示例，按你的领域改写。
- `workbench/dashboard-config.json`：把"示例周"改成你的真实日期与待办。
- `AGENTS.md`：把【】里的用户背景补上，Agent 才不会乱猜。

版本：模板 v0.1 · 2026-11-15
