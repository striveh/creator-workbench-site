# tools 使用说明

`workbench.py` 是创作者工作台的命令行工具：**只用 Python 标准库**，不需要安装任何依赖。

要求：Python 3.8+（macOS 自带 `python3` 即可）。

---

## 一、命令速查

### 1. `new`：新建一篇内容

```bash
python3 workbench/tools/workbench.py new "标题" --slug english-slug
```

会在项目根目录 `content/` 下创建：

```
content/YYYY-MM-DD-english-slug/
├── article.md      # 文章骨架
├── meta.json       # 内容元数据
├── imgs/           # 配图目录
└── prompts/        # 配图提示词目录
```

参数：

| 参数 | 必填 | 说明 |
|---|---|---|
| `title` | 是 | 中文标题，可含空格和标点 |
| `--slug` | 否 | 目录英文 slug；不填则自动生成（中文标题会生成 `article-xxxxxx`） |
| `--date` | 否 | 创建日期 `YYYY-MM-DD`，默认今天 |
| `--column` | 否 | 栏目：`AI 落地实战` / `技术人转型` / `工具与工作台` / `行业判断` |
| `--status` | 否 | 初始状态：`选题`（默认）/ `写作` / `待发布` / `已发布` |
| `--content-dir` | 否 | 覆盖 content 目录（用于测试） |

示例：

```bash
python3 workbench/tools/workbench.py new "企业第一个 AI 项目别做聊天机器人" \
  --slug first-ai-project --column "AI 落地实战"
```

### 2. `list`：按状态列出内容

```bash
python3 workbench/tools/workbench.py list
python3 workbench/tools/workbench.py list --status 写作
python3 workbench/tools/workbench.py list --json
```

输出按 `选题 → 写作 → 待发布 → 已发布` 排序，每篇显示日期、标题、栏目和目录路径。

### 3. `status`：修改内容状态

```bash
python3 workbench/tools/workbench.py status my-first-article 待发布
python3 workbench/tools/workbench.py status my-first-article 已发布
```

`target` 可以是目录名、slug 或标题关键词。

### 4. `dashboard`：生成可视化看板

```bash
python3 workbench/tools/workbench.py dashboard
python3 workbench/tools/workbench.py dashboard --open
```

生成 `workbench/dashboard.html`，可直接双击用浏览器打开。看板包含：

- 内容流水线：选题 / 写作 / 待发布 / 已发布四列；
- 90 天目标进度：读取 `workbench/dashboard-config.json`，其中 `metric: "published"` 的目标按已发布内容数自动计算；
- 本周待办：读取 `dashboard-config.json` 的 `week.todos`；
- 今日建议：根据流水线状态自动推荐下一步动作。

看板数据来自 `content/*/meta.json`，修改内容后重新运行一次即可刷新。

### 5. 帮助

```bash
python3 workbench/tools/workbench.py --help
python3 workbench/tools/workbench.py new --help
```

---

## 二、meta.json 字段说明

新建时自动生成，字段如下（可手动修改）：

```json
{
  "title": "我的第一篇内容",
  "slug": "my-first-post",
  "status": "选题",
  "column": "技术人转型",
  "created": "YYYY-MM-DD",
  "updated": "YYYY-MM-DDTHH:MM:SS",
  "target_reader": "待填写",
  "platforms": ["公众号", "小红书", "视频号"],
  "tags": [],
  "summary": "",
  "cover": "",
  "files": {
    "article": "article.md",
    "imgs": "imgs/",
    "prompts": "prompts/"
  }
}
```

| 字段 | 说明 |
|---|---|
| `title` | 标题；缺失时自动读取 article.md 的一级标题 |
| `status` | 必须是四个标准状态之一；也兼容 `idea` / `draft` / `ready` / `published` 等英文写法 |
| `column` | 栏目；也兼容 `栏目`、`pillar`、`category` 等字段名 |
| `created` | 创建日期 `YYYY-MM-DD` |
| `platforms` | 计划发布的平台数组 |
| `summary` | 看板卡片摘要；不填则自动截取正文第一段 |
| `tags` | 标签数组；没有 `column` 时第一个标签会作为栏目显示 |

> 兼容性：`workbench.py` 会容忍不同的字段名（如 `标题`、`状态`、`栏目`、`平台`），所以其他人手动创建的 meta.json 也能被读取和展示。

---

## 三、dashboard-config.json 说明

这个文件控制看板上的「90 天目标」和「本周待办」，属于手动维护的运营配置。

### 目标进度类型

| `metric` | 计算方式 |
|---|---|
| `published` | 统计 `status == "已发布"` 的内容数量 |
| `total` | 统计全部内容数量 |
| `writing` | 统计 `status == "写作"` 的内容数量 |
| `manual` | 用手动填写的 `done` 值 |

示例：

```json
{
  "title": "30 天发布 10 篇内容",
  "target": 10,
  "metric": "published",
  "unit": "篇",
  "note": "公众号 4 + 小红书 20 + 视频 6"
}
```

每周更新：

1. 把 `week.label` 改成当前周次；
2. 把上周未完成的待办删掉或勾选 `done: true`；
3. 写入本周 3–5 条待办；
4. 运行 `dashboard` 重新生成。

---

## 四、常见问题

### Q1：提示 `python3: command not found`

macOS 可安装 Xcode Command Line Tools：`xcode-select --install`，或使用 `python3` 的绝对路径。

### Q2：中文标题生成的目录名是 `article-xxxxxx`

因为 Python 标准库无法做中文转拼音。用 `--slug` 指定英文目录名即可，例如：

```bash
python3 workbench/tools/workbench.py new "我的标题" --slug my-title
```

### Q3：看板里看不到刚建的文章

重新运行：

```bash
python3 workbench/tools/workbench.py dashboard
```

并确认 article 目录下有 `meta.json`。

### Q4：想批量修改状态

可以直接编辑各目录下的 `meta.json`，或使用 `status` 命令逐个修改。

### Q5：能用在其他电脑上吗

可以。整个 `workbench/` + `content/` 目录复制走即可；`workbench.py` 不依赖任何第三方库。

---

## 五、目录约定

```
项目根目录/
├── content/                    # 所有内容（由 CLI 创建）
└── workbench/
    ├── dashboard.html          # 生成物，不要手改
    ├── dashboard-config.json   # 看板配置，手动维护
    └── tools/
        ├── workbench.py        # CLI
        └── README.md           # 本文件
```

---

版本：模板 v0.1 · 2026-11-15
